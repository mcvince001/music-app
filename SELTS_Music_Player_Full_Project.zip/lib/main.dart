// Main Dart file for SELTS Music Player
void main() => runApp(MyApp());